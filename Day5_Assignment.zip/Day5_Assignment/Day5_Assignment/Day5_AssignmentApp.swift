//
//  Day5_AssignmentApp.swift
//  Day5_Assignment
//
//  Created by Taibah Valley Academy on 06/09/1446 AH.
//

import SwiftUI

@main
struct Day5_AssignmentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
