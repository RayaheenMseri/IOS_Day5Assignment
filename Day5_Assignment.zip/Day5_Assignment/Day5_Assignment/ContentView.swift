//
//  ContentView.swift
//  Day5_Assignment
//
//  Created by Taibah Valley Academy on 06/09/1446 AH.
//

import SwiftUI

struct ContentView: View {
    @State private var userName: String = "Rayaheen"
    @State private var newName: String = "" // To store user input from TextField
    @State private var isDarkMode: Bool = false // To store the state of the toggle

    var body: some View {
        VStack {
            ZStack {
                // check the background color to changes based on dark mode
                isDarkMode ? Color.black.edgesIgnoringSafeArea(.all) : Color.white.edgesIgnoringSafeArea(.all)

                VStack {
                    // Displaying the user name
                    Text("Hello, \(userName)!")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(isDarkMode ? .white : .black)
                        .padding()

                    // TextField to input the user name
                    TextField("Enter your name", text: $newName)
                        .padding()
                        .background(isDarkMode ? Color.white: Color.gray.opacity(0.2))
                        .cornerRadius(10)
                        .padding(.horizontal)

                    // Button to update the label with the user name
                    Button(action: {
                        // Update userName with newName
                        if !newName.isEmpty {
                            userName = newName
                        }
                    }) {
                        Text("Update Name!")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(10)
                    }
                    .padding()

                    // Using the DarkModeToggle view to change dark mode
                    DarkModeToggle(isDarkMode: $isDarkMode)
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
